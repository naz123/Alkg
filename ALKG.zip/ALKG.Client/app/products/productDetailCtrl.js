﻿(function () {
  "use strict";

  angular
      .module("productManagement")
      .controller("ProductDetailCtrl",
                  ["uiGridConstants", "customerResource", "$stateParams","$http",
                   ProductDetailCtrl]);

  function ProductDetailCtrl(uiGridConstants, customerResource, $stateParams, $http) {
    var vm = this;
    vm.gridOptions = {      
      enableRowSelection: true,
      paginationPageSizes: [10, 15, 20],
      enablePaginationControls: true,
      selection: 'single',
      selectionRowHeaderWidth: 35,
      rowHeight: 35,
      showGridFooter: true,
      enableGridMenu: true,
      enableFiltering: true,
      enableSorting: true,
      columnDefs: [
        { name: 'name' },
        { name: 'description' },
        {
          name: 'Edit Product', headerTooltip: 'Click to edit product', enableSorting: false, enableFiltering: false,
          cellTemplate: '<div>' +
                '<a ui-sref="productEdit({ productId: row.entity.id })">edit</a>' +
                '</div>'
        },
        {
          name: 'Delete Product', headerTooltip: 'Click to edit product', enableSorting: false, enableFiltering: false,
          cellTemplate: '<div>' +
                '<a class="btn btn primary" ng-click="grid.appScope.vm.deleteProduct(row.entity.id)">delete</a>' +
                '</div>'
        }        
      ]
    };

    var customerId = $stateParams.customerId;

    customerResource.query({ customerId: customerId }, function (data) {      
      vm.gridOptions.data = data;      
    });

    vm.deleteProduct = function (id) {
      $http({
        method: "DELETE",
        url: 'http://localhost:51105/api/product',
        params: { id: id }
      })
        .then(function (response) {
          // success
          toastr.success("Product Deleted");
          $state.go('customerList');
        }, function (response) {
          toastr.error("Error occured please contact help desk");
        });
    }
  }
}());
