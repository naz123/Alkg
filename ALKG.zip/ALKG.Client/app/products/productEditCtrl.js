﻿(function () {
  "use strict";

  angular
      .module("productManagement")
      .controller("ProductEditCtrl",
      ["$stateParams", "$state", "$http", ProductEditCtrl]);

  function ProductEditCtrl($state, $stateParams, $http) {
    var vm = this;
    vm.product = {};

    $http({
      method: "GET",
      url: 'http://localhost:51105/api/product',
      params: { productId: $stateParams.params.productId }
    })
    .then(function (response) {      
      vm.product = response.data;      
    }, function () {
      toastr.error("Error occured please contact help desk");
    });
     
    vm.originalProduct = angular.copy(vm.product);
    vm.submit = function (product) {
      if (product.id) {
          $http({
            method: "POST",
            url: 'http://localhost:51105/api/product',
            data: product
          })
         .then(function (response) {
           // success
           toastr.success("Product Saved");
           $state.go('customerList');           
         }, function (response) {
           toastr.error("Error occured please contact help desk");
         });
      }
    }

    vm.cancel = function () {
      vm.product = angular.copy(vm.originalProduct);
    };    
  }
}());
