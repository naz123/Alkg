/// <reference path="products/productEdit.html" />
/// <reference path="products/productEdit.html" />

(function () {
  "use strict";

  var app = angular.module("productManagement",
                          ["common.services",
                          "ui.router",
                          "ui.bootstrap", "ui.grid", "ui.grid.selection", "ui.grid.pagination", "ui.grid.edit", "ui.grid.rowEdit",
                          "ui.grid.edit", "ui.grid.resizeColumns"]);

  app.config(["$stateProvider",
            "$urlRouterProvider",
            function ($stateProvider, $urlRouterProvider) {
              $urlRouterProvider.otherwise("/");

              $stateProvider
                .state("home", {
                  url: "/",
                  templateUrl: "app/welcomeView.html"
                  })
                 // Customers
                .state("customerList", {
                  url: "/customers",
                  templateUrl: "app/customers/customerListView.html",
                  controller: "CustomerListCtrl as vm"
                })
                .state("productAdd", {
                  url: "/product/add/:customerId",
                  templateUrl: "app/products/productAdd.html"
                  })
                 .state("productDetail", {
                   url: "/products/:customerId",
                   templateUrl: "app/products/productDetailView.html"
                 })
                 .state("productEdit", {
                    url: "/product/edit/:productId",
                    templateUrl: "app/products/productEdit.html"                    
                  })
            }])

}());
