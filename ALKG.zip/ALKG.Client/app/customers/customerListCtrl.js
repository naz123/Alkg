(function () {
  "use strict";
  angular
      .module("productManagement")
      .controller("CustomerListCtrl",
                   ["customerResource", "uiGridConstants",
                       CustomerListCtrl]);

  function CustomerListCtrl(customerResource, uiGridConstants) {
    var vm = this;

    vm.customers = [];
    vm.gridOptions = {
      enableRowSelection: true,
      paginationPageSizes: [25, 50, 75],
      enablePaginationControls: true,
      selection: 'single',
      selectionRowHeaderWidth: 35,
      rowHeight: 35,
      showGridFooter: true,
      enableGridMenu: true,
      enableFiltering: true,
      enableSorting: true,
      columnDefs: [
        { name: 'firstName' },
        { name: 'lastName' },
        { name: 'email' },        
        { name: 'Product', headerTooltip: 'Click to view products', enableSorting: false, enableFiltering: false,
          cellTemplate:'<div>' +
                '<a ui-sref="productDetail({ customerId: row.entity.customerId })">view product </a>' +
                '</div>' }]
    };

    vm.gridOptions.multiSelect = false;

    vm.isBusy = true;
    vm.hideGrid = true;
    customerResource.query(function (data) {
      //vm.customers = data;
      vm.gridOptions.data = data;
      vm.isBusy = false;
      vm.hideGrid = false;
    });

    vm.gridOptions.onRegisterApi = function (gridApi) {
      //set gridApi on scope
      vm.gridApi = gridApi;
      gridApi.selection.on.rowSelectionChanged(null, function (row) {
        var msg = 'row selected ' + row.isSelected;
        console.log(row.entity.customerId);
      });

    }
  }
}());
